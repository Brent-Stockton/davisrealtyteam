declare module "@heroicons/react/24/outline" {
  export { default as Bars3Icon } from "@heroicons/react/24/outline/Bars3Icon";
  export { default as XMarkIcon } from "@heroicons/react/24/outline/XMarkIcon";
  // ... declare other icons as needed
}
